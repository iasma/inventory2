package com.example.android.inventory;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.inventory.data.StoreContract.StoreEntry;


public class Detail extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    int quantity ;
    private Uri mCurrentItemUri;
    private TextView name;
    private TextView price;
    private TextView quantity1;
    private TextView supplierName;
    private TextView phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        Intent intent = getIntent();
        mCurrentItemUri = intent.getData();

        name = (TextView) findViewById(R.id.name);
        price = (TextView) findViewById(R.id.price);
        quantity1 = (TextView) findViewById(R.id.quantity_text_view);
        supplierName = (TextView) findViewById(R.id.supplierName);
        phone = (TextView) findViewById(R.id.supplierPhone);




        Button editItem = (Button) findViewById(R.id.editButton);
        editItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Detail.this, EditItem.class);
                intent.setData(mCurrentItemUri);
                startActivity(intent);
            }
        });

        Button deleteItem = (Button) findViewById(R.id.deleteButton);
        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteConfirmationDialog();
            }
        });



    }


    public void increment(View view){

        quantity = quantity +1;

    }



    public void decrement(View view){

        quantity = quantity -1;
        if (quantity < 0){ quantity = 0;}

    }


    private void deletItem() {
        if (mCurrentItemUri != null) {

            int rowsDeleted = getContentResolver().delete(mCurrentItemUri, null, null);

            if (rowsDeleted == 0) {
                Toast.makeText(this, "Error with deleting item", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Item Deleted", Toast.LENGTH_SHORT).show();
            }
        }

        finish();
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        String[] projection = {
                StoreEntry._ID,
                StoreEntry.COLUMN_PRODUCT_NAME,
                StoreEntry.COLUMN_PRICE,
                StoreEntry.COLUMN_QUANTITY,
                StoreEntry.COLUMN_SUPPLIER_NAME,
                StoreEntry.COLUMN_SUPPLIER_PHONE_NUMBER};

        return new CursorLoader(this, mCurrentItemUri, projection,
                null, null,null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        if(cursor == null || cursor.getCount() < 1){
            return;
        }


        if (cursor.moveToFirst()) {

            int nameColumnIndex = cursor.getColumnIndex(StoreEntry.COLUMN_PRODUCT_NAME);
            int priceColumnIndex = cursor.getColumnIndex(StoreEntry.COLUMN_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(StoreEntry.COLUMN_QUANTITY);
            int suppNameColumnIndex = cursor.getColumnIndex(StoreEntry.COLUMN_SUPPLIER_NAME);
            int phoneColumnIndex = cursor.getColumnIndex(StoreEntry.COLUMN_SUPPLIER_PHONE_NUMBER);

            String name1 = cursor.getString(nameColumnIndex);
            int price1 = cursor.getInt(priceColumnIndex);
            int quantity = cursor.getInt(quantityColumnIndex);
            String supplierName1 = cursor.getString(suppNameColumnIndex);
            String phone1 = cursor.getString(phoneColumnIndex);


            name.setText(name1);
            price.setText(price1);
            quantity1.setText(quantity);
            supplierName.setText(supplierName1);
            phone.setText(phone1);


            final String phoneCall = "+" + phone1;
            Button order = (Button) findViewById(R.id.order);
            order.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneCall, null ));
                    startActivity(intent);
                }
            });

        }

        }


    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        name.setText("");
        price.setText("");
        quantity1.setText("");
        supplierName.setText("");
        phone.setText("");
    }


    private void showDeleteConfirmationDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Delete this Item");
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                deletItem();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
