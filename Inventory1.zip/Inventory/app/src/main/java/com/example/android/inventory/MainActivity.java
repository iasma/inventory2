package com.example.android.inventory;

import android.app.LoaderManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


import com.example.android.inventory.data.StoreContract;
import com.example.android.inventory.data.StoreContract.StoreEntry;


public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>{


    private static final int STORE_LOADER = 0;
    StoreCursorAdapter mCursorAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EditItem.class);
                startActivity(intent);
            }
        });

        ListView listView = (ListView) findViewById(R.id.list);

        View emptyView = findViewById(R.id.emptyView);
        listView.setEmptyView(emptyView);

        mCursorAdapter = new StoreCursorAdapter(this, null);
        listView.setAdapter(mCursorAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, Detail.class);
                Uri currentItemUri = ContentUris.withAppendedId(StoreEntry.CONTENT_URI, id);
                intent.setData(currentItemUri);
                startActivity(intent);
            }
        });

        getLoaderManager().initLoader(STORE_LOADER, null, this);

    }

    private  void insertData () {

        ContentValues values = new ContentValues();

        values.put(StoreEntry.COLUMN_PRODUCT_NAME, "Milk");
        values.put(StoreEntry.COLUMN_PRICE, 10);
        values.put(StoreEntry.COLUMN_QUANTITY, 40);
        values.put(StoreEntry.COLUMN_SUPPLIER_NAME, "Almaraay");
        values.put(StoreEntry.COLUMN_SUPPLIER_PHONE_NUMBER, "032985275");


        Uri newUri = getContentResolver().insert(StoreEntry.CONTENT_URI, values);

    }

    private void deleteAllItems(){
        int rowsDeleted = getContentResolver().delete(StoreEntry.CONTENT_URI, null, null);
        Log.v("MainActivity", rowsDeleted + " rows deleted from store database");
    }

    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()) {

            case R.id.actionInsertDummyData:
                insertData();
                return true;

            case R.id.actionDeleteAllEntries:
                deleteAllItems();
                return true;
        }

        return super.onOptionsItemSelected(item);

    }



    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        String [] projection = {

                StoreContract.StoreEntry._ID,
                StoreContract.StoreEntry.COLUMN_PRODUCT_NAME,
                StoreContract.StoreEntry.COLUMN_PRICE,
                StoreContract.StoreEntry.COLUMN_QUANTITY
        };

        return new CursorLoader(this, StoreContract.StoreEntry.CONTENT_URI,
                projection, null, null, null);

    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        mCursorAdapter.swapCursor(data);

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        mCursorAdapter.swapCursor(null);

    }
}
