package com.example.android.inventory;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.inventory.data.StoreContract;

/**
 * Created by asmaowaid on 16/02/2018.
 */

public class StoreCursorAdapter extends CursorAdapter {

    public StoreCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.listitem, parent, false);
    }

    @Override
    public void bindView(View view, final Context context, Cursor cursor) {

        TextView nameTextView = (TextView) view.findViewById(R.id.name);
        TextView priceTextView = (TextView) view.findViewById(R.id.price);
        final TextView quantityTextView = (TextView) view.findViewById(R.id.quantity);
        Button sale = (Button) view.findViewById(R.id.sale);



        final int idColumnIndex = cursor.getColumnIndex(StoreContract.StoreEntry._ID);
        int nameColumnIndex = cursor.getColumnIndex(StoreContract.StoreEntry.COLUMN_PRODUCT_NAME);
        int priceColumnIndex = cursor.getColumnIndex(StoreContract.StoreEntry.COLUMN_PRICE);
        int quantityColumnIndex = cursor.getColumnIndex(StoreContract.StoreEntry.COLUMN_QUANTITY);

        String productName = cursor.getString(nameColumnIndex);
        String itemPrice = cursor.getString(priceColumnIndex);
        String itemQuantity = cursor.getString(quantityColumnIndex);


        nameTextView.setText(productName);
        priceTextView.setText(itemPrice);
        quantityTextView.setText(itemQuantity);

        final int qua = Integer.valueOf(itemQuantity);


        if(qua == 0) {

            sale.setText("Sold");
        }else {
            sale.setText("on stock");
        }


        sale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri uri = ContentUris.withAppendedId(StoreContract.StoreEntry.CONTENT_URI, idColumnIndex);
                saleButton(context, uri, qua , quantityTextView );
            }
        });


    }

    private void saleButton(Context context, Uri uri, int quantity, View view) {

        if (quantity <0 || quantity ==0){

            Toast.makeText(context.getApplicationContext(),"Product out of stock", Toast.LENGTH_SHORT).show();
        } else {
            quantity++;
            ContentValues contentValues = new ContentValues();
            contentValues.put(StoreContract.StoreEntry.COLUMN_QUANTITY, quantity);
            context.getContentResolver().update(uri, contentValues, null, null);
            String qu = String.valueOf(quantity);
            final TextView quantityTextView = (TextView) view.findViewById(R.id.quantity);
            quantityTextView.setText(qu);
        }
    }
}
